# Define tha base class Player
class Player:
  def play(self):
    print ("The player is playing cricket.")

# Define tha derived class Batsman
class Batsman (Player):
  def play(self):
    print ("Tha Batsman is playing.")

# Define tha derived clss Bowler
class Bowlar(Player):
  def play (self):
    print("The Bowlar is bowing")

# Create object of Batsman and Bowlar classes
batsman = Batsman ()
bowlar = Bowlar()

# Call tha play() method for each object
batsman.play()
bowlar.play()
